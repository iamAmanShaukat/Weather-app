import React, { Fragment } from 'react';

import Header from '../Header';

const Page = () => {
    return (
        <Fragment>
            <Header />
        </Fragment>
    );
};

export default Page;
